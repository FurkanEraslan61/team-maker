import React, { useState } from 'react';

function App() {
  const [players, setPlayers] = useState([
    { name: 'Ali', position: 'Kaleci', coming: true },
    { name: 'Mehmet', position: 'Kaleci', coming: true },
    { name: 'Furkan', position: 'Orta Saha', coming: false },
    { name: 'Halil', position: 'Defans', coming: false },
    // Devamı sana kalmış
  ]);

  return (
    <div>
      <h1>Team Maker</h1>
      <ul>
        {players.map((p, i) => (
          <li key={i}>
            {p.name} - {p.position} - {p.coming ? 'GELİYOR' : 'YOK'}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
